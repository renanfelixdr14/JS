var inputID = document.getElementById('id')
var inputNome = document.getElementById('nome')
var selectSexo = document.getElementById('sexo')
var selectStatus = document.getElementById('status')
var btGravar = document.getElementById('btnGravar')
var btLimpar = document.getElementById('btnLimpar')
var btSexo = document.getElementsByClassName('btSexo')
var divAlert = document.getElementById('alert')
var btMostrar = document.getElementById('btMostrar')
const pessoas = [];
var API = `https://appwll.com.br/api/funcionarios`;



// ExibirAll();

btGravar.addEventListener('click', async function(){

    let response = await fetch(API);
    let apiJson = await response.json();
    
carregarFuncionarios();

});


//Puxando Dados diretamente da API para a tela
async function carregarFuncionarios() {
    let response = await fetch(API);
    let apiJson = await response.json();
    let linhas = "";

    apiJson.forEach((clt) => {
        linhas += `<tr>`;
        linhas += `<td>${clt.id}</td>`;
        linhas += `<td>${clt.nome}</td>`;
        linhas += `<td>${clt.privilegio_id}</td>`;
        linhas += `<td>${clt.privilegio}</td>`;
        linhas += `<td><button class="btn btn-info" onClick="editar(${clt.id})">Editar</button></td>`;
        linhas += `<td><button class="btn btn-danger" onClick="excluir(${clt.id})">Excluir</button></td>`;
        linhas += `</tr>`;
    });

    conteudo.innerHTML = linhas;
}
//Deletando diretamente da API
async function excluir(id){
    let deleteFromAPI = `https://appwll.com.br/api/funcionarios/${id}`;
    deleteFromAPI = await fetch(deleteFromAPI,{
        method:'DELETE'
    })
    
    carregarFuncionarios();

    
}
